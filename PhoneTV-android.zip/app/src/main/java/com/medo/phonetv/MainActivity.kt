package com.medo.phonetv

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {

    private val reqCapture = 1001
    private lateinit var ipView: TextView
    private lateinit var statusView: TextView
    private lateinit var keyView: TextView
    private lateinit var logView: TextView
    private lateinit var btn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        fun tv(size: Float, color: Int = Color.WHITE) = TextView(this).apply {
            textSize = size
            setTextColor(color)
            setPadding(0, 12, 0, 12)
        }
        val title = tv(26f)
        title.text = "PhoneTV - Receiver"
        ipView = tv(22f, Color.parseColor("#FF9800"))
        statusView = tv(18f, Color.parseColor("#AAAAAA"))
        btn = Button(this)
        keyView = tv(48f, Color.parseColor("#4CAF50")).apply { gravity = Gravity.CENTER_HORIZONTAL }
        logView = tv(16f, Color.parseColor("#BBBBBB"))

        btn.setOnClickListener {
            if (Hub.running) stopStream() else requestCapture()
        }

        root.addView(title)
        root.addView(ipView)
        root.addView(statusView)
        root.addView(btn)
        root.addView(keyView)
        root.addView(logView)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        Hub.listener = { runOnUiThread { refresh() } }
        refresh()
    }

    override fun onPause() {
        Hub.listener = null
        super.onPause()
    }

    private fun refresh() {
        ipView.text = "IP: " + (localIp() ?: "not on Wi-Fi") + "   Port: " + PORT
        statusView.text = Hub.status
        keyView.text = Hub.lastKey
        logView.text = Hub.logText()
        btn.text = if (Hub.running) "Stop streaming" else "Start streaming"
    }

    private fun requestCapture() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    private fun stopStream() {
        val i = Intent(this, StreamService::class.java).setAction(StreamService.ACTION_STOP)
        startService(i)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, StreamService::class.java)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
        } else if (requestCode == reqCapture) {
            Hub.updateStatus("Capture permission denied")
        }
    }

    private fun localIp(): String? {
        try {
            val ifs = NetworkInterface.getNetworkInterfaces()
            while (ifs.hasMoreElements()) {
                val ni = ifs.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress
                }
            }
        } catch (_: Exception) {
        }
        return null
    }
}
