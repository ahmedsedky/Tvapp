package com.medo.phonetv

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import java.io.ByteArrayOutputStream

class StreamService : Service() {

    companion object {
        const val ACTION_STOP = "com.medo.phonetv.STOP"
        const val CHANNEL = "phonetv_stream"
        const val MAX_SIDE = 1280f
        const val MIN_FRAME_MS = 66L      // ~15 fps
        const val JPEG_QUALITY = 60
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var server: KeyServer? = null
    private var lastFrameAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            stopSelf()
            return START_NOT_STICKY
        }
        goForeground()
        if (projection != null) return START_NOT_STICKY

        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra("data")
        val code = intent?.getIntExtra("code", 0) ?: 0
        if (data == null) {
            Hub.updateStatus("No capture permission")
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startServer()
            startCapture(code, data)
            Hub.updateRunning(true)
        } catch (e: Exception) {
            Hub.updateStatus("Error: " + e.message)
            shutdown()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "PhoneTV streaming", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("PhoneTV")
            .setContentText("Streaming the screen to the TV")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun startServer() {
        val s = KeyServer()
        s.setReuseAddr(true)
        s.start()
        server = s
        Hub.updateStatus("Server running, waiting for the TV...")
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        projection = p

        val m = resources.displayMetrics
        val scale = MAX_SIDE / maxOf(m.widthPixels, m.heightPixels)
        val w = ((m.widthPixels * scale).toInt() / 2) * 2
        val h = ((m.heightPixels * scale).toInt() / 2) * 2

        val t = HandlerThread("phonetv-capture")
        t.start()
        thread = t
        val handler = Handler(t.looper)

        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, handler)

        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        display = p.createVirtualDisplay(
            "PhoneTV", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )
        r.setOnImageAvailableListener({ rd -> onFrame(rd) }, handler)
    }

    private fun onFrame(rd: ImageReader) {
        val img = try {
            rd.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastFrameAt < MIN_FRAME_MS) return
            val srv = server ?: return
            val clients = srv.connections
            if (clients.isEmpty()) return
            lastFrameAt = now

            val w = img.width
            val h = img.height
            val plane = img.planes[0]
            val padW = plane.rowStride / plane.pixelStride
            var bmp = Bitmap.createBitmap(padW, h, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(plane.buffer)
            if (padW != w) {
                val cropped = Bitmap.createBitmap(bmp, 0, 0, w, h)
                bmp.recycle()
                bmp = cropped
            }
            val out = ByteArrayOutputStream(64 * 1024)
            bmp.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
            bmp.recycle()
            val bytes = out.toByteArray()

            for (c in clients) {
                if (c.isOpen && !c.hasBufferedData()) c.send(bytes)
            }
        } catch (_: Exception) {
        } finally {
            img.close()
        }
    }

    private fun shutdown() {
        try { reader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        try { display?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { server?.stop(300) } catch (_: Exception) {}
        try { thread?.quitSafely() } catch (_: Exception) {}
        display = null
        reader = null
        projection = null
        server = null
        thread = null
        Hub.updateRunning(false)
        Hub.updateStatus("Stopped")
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }
}
