package com.medo.phonetv

import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import java.net.InetSocketAddress

const val PORT = 8765

class KeyServer : WebSocketServer(InetSocketAddress(PORT)) {

    override fun onOpen(conn: WebSocket?, handshake: ClientHandshake?) {
        Hub.setStatus("TV connected: " + conn?.remoteSocketAddress?.address?.hostAddress)
    }

    override fun onClose(conn: WebSocket?, code: Int, reason: String?, remote: Boolean) {
        Hub.setStatus("TV disconnected")
    }

    override fun onMessage(conn: WebSocket?, message: String?) {
        if (message == null) return
        try {
            val j = JSONObject(message)
            if (j.optString("type") == "key") {
                Hub.addKey(j.optString("name"), j.optInt("code"))
            }
        } catch (_: Exception) {
        }
    }

    override fun onError(conn: WebSocket?, ex: Exception?) {
        Hub.setStatus("Error: " + ex?.message)
    }

    override fun onStart() {}
}
