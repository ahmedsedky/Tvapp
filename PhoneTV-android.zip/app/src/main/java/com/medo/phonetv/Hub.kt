package com.medo.phonetv

object Hub {
    @Volatile var status: String = "Stopped"
    @Volatile var running: Boolean = false
    @Volatile var lastKey: String = "-"
    @Volatile var listener: (() -> Unit)? = null
    private val lines = ArrayList<String>()

    fun setStatus(s: String) {
        status = s
        listener?.invoke()
    }

    fun setRunning(r: Boolean) {
        running = r
        listener?.invoke()
    }

    fun addKey(name: String, code: Int) {
        synchronized(lines) {
            lines.add(0, "$name ($code)")
            while (lines.size > 10) lines.removeAt(lines.size - 1)
        }
        lastKey = name
        listener?.invoke()
    }

    fun logText(): String = synchronized(lines) { lines.joinToString("\n") }
}
