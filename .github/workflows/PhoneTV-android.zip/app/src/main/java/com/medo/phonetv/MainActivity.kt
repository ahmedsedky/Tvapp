package com.medo.phonetv

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import org.java_websocket.WebSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface

const val PORT = 8765

class MainActivity : Activity() {

    private var server: KeyServer? = null
    private lateinit var ipView: TextView
    private lateinit var statusView: TextView
    private lateinit var keyView: TextView
    private lateinit var logView: TextView
    private val lines = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }
        fun tv(size: Float, color: Int = Color.WHITE) = TextView(this).apply {
            textSize = size
            setTextColor(color)
            setPadding(0, 12, 0, 12)
        }
        val title = tv(26f)
        title.text = "PhoneTV - Receiver"
        ipView = tv(22f, Color.parseColor("#FF9800"))
        statusView = tv(18f, Color.parseColor("#AAAAAA"))
        keyView = tv(48f, Color.parseColor("#4CAF50")).apply { gravity = Gravity.CENTER_HORIZONTAL }
        keyView.text = "-"
        logView = tv(16f, Color.parseColor("#BBBBBB"))

        root.addView(title)
        root.addView(ipView)
        root.addView(statusView)
        root.addView(keyView)
        root.addView(logView)
        setContentView(root)

        ipView.text = "IP: " + (localIp() ?: "not on Wi-Fi") + "   Port: " + PORT
        startServer()
    }

    private fun startServer() {
        try {
            val s = KeyServer(
                onStatus = { msg -> runOnUiThread { statusView.text = msg } },
                onKey = { name, code -> runOnUiThread { showKey(name, code) } }
            )
            s.setReuseAddr(true)
            s.start()
            server = s
            statusView.text = "Server running, waiting for the TV..."
        } catch (e: Exception) {
            statusView.text = "Server error: " + e.message
        }
    }

    private fun showKey(name: String, code: Int) {
        keyView.text = name
        lines.add(0, "$name ($code)")
        while (lines.size > 12) lines.removeAt(lines.size - 1)
        logView.text = lines.joinToString("\n")
    }

    private fun localIp(): String? {
        try {
            val ifs = NetworkInterface.getNetworkInterfaces()
            while (ifs.hasMoreElements()) {
                val ni = ifs.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress
                }
            }
        } catch (_: Exception) {
        }
        return null
    }

    override fun onDestroy() {
        try {
            server?.stop(300)
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}

class KeyServer(
    private val onStatus: (String) -> Unit,
    private val onKey: (String, Int) -> Unit
) : WebSocketServer(InetSocketAddress(PORT)) {

    override fun onOpen(conn: WebSocket?, handshake: ClientHandshake?) {
        onStatus("TV connected: " + conn?.remoteSocketAddress?.address?.hostAddress)
    }

    override fun onClose(conn: WebSocket?, code: Int, reason: String?, remote: Boolean) {
        onStatus("TV disconnected")
    }

    override fun onMessage(conn: WebSocket?, message: String?) {
        if (message == null) return
        try {
            val j = JSONObject(message)
            if (j.optString("type") == "key") {
                onKey(j.optString("name"), j.optInt("code"))
            }
        } catch (_: Exception) {
        }
    }

    override fun onError(conn: WebSocket?, ex: Exception?) {
        onStatus("Error: " + ex?.message)
    }

    override fun onStart() {}
}
